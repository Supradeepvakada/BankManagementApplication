module BankManagemenetApplication {
	requires java.sql;
}