package com.fis.accountmanagement.beans;

public class Accounts {
	private long accNo;
	private String custName;
	private long mobileNo;
	private String accType;
	private String branch;
	private double balance;

	@Override
	public String toString() {
		return " Account Number = " + accNo + "\n Customer Name = " + custName + "\n Mobile Number = " + mobileNo + "\n Account Type = " + accType
				+ "\n Branch = " + branch + "\n Balance = " + balance ;
	}
	public Accounts(long accNo, String custName, long mobileNo, String accType, String branch, double balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.mobileNo = mobileNo;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
	}
	public Accounts() {
	}
	/**
	 * @return the accNo
	 */
	public long getAccNo() {
		return accNo;
	}
	/**
	 * @param accNo the accNo to set
	 */
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	/**
	 * @return the custName
	 */
	public String getCustName() {
		return custName;
	}
	/**
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	/**
	 * @return the mobile
	 */
	public long getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return the accType
	 */
	public String getAccType() {
		return accType;
	}
	/**
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the balance
	 */
	public double getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
