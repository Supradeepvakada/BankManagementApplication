package com.fis.accountmanagement.repo;

import com.fis.accountmanagement.beans.Accounts;
import com.fis.accountmanagement.exceptions.AccountNotFound;
import com.fis.accountmanagement.exceptions.NotEnoughBalance;

public interface AccClientRepo {
	public abstract String addAccount(Accounts account);

	public abstract Accounts getAccount(long getAcc) throws AccountNotFound;

	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;

	public abstract void depositIntoBalance(long getAcc, double depositAmount);
}
