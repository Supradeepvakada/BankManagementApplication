package com.fis.accountmanagement.exceptions;

public class NotEnoughBalance extends Exception {
	public NotEnoughBalance(String message) {
		super(message);
	}
}
