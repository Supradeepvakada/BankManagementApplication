package com.fis.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DDL_Ex {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankmanagementapplication", "root", "MonkeyDLuffy@01");
		// creating the statement,preparedStatement,CallableStatement
		Statement stmt = conn.createStatement();
		// execute the query ddl--execute(), dml--executeUpdate() drl-->executeQuery()
		boolean result = stmt.execute("create table details(accNo int, custName varchar(40), mobileNo double, accType varchar(40), branch varchar(40), balance double)");
		// close the connection
		conn.close();
		System.out.println("table created " + result);
	}
}
